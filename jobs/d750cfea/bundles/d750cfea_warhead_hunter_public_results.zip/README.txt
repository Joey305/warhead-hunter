Warhead Hunter Public Result Bundle — d750cfea

This bundle contains cleaned/prepared, job-derived outputs intended for downstream inspection.
Typical contents include final CSV summaries, cleaned ligand-bound PDB files, ligand SDF files,
SVG atom maps, and job-level metadata relevant to API-driven retrieval workflows.

This bundle intentionally excludes copied pipeline scripts, raw coordinate CIF files,
and rebuildable intermediate clutter unless explicitly requested.
Generated from job_result_manifest.json at 2026-05-18T21:26:49+00:00.
